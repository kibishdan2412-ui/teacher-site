# -*- coding: utf-8 -*-
"""Точка входу. Стани: MENU -> LEVEL_SELECT -> PLAYING -> (WON/LOST) -> MENU."""
import sys
import asyncio
import pygame
import settings as S
from ui import Button, draw_text, FONT_S, FONT_M, FONT_L, FONT_XL
from waves import CAMPAIGN_LEVELS
from game import Level


class App:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(S.TITLE)
        self.screen = pygame.display.set_mode((S.SCREEN_WIDTH, S.SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()
        self.state = "menu"
        self.level = None
        self._build_menu()

    # ------------------------------------------------------------------
    def _build_menu(self):
        cx = S.SCREEN_WIDTH // 2
        self.menu_buttons = [
            Button((cx - 140, 320, 280, 55), "Кампанія", font=FONT_L),
            Button((cx - 140, 390, 280, 55), "Безперервний режим", font=FONT_L),
            Button((cx - 140, 460, 280, 50), "Вихід", font=FONT_M),
        ]

        self.level_buttons = []
        for i, lvl in enumerate(CAMPAIGN_LEVELS):
            rect = (cx - 220, 180 + i * 75, 440, 60)
            self.level_buttons.append(Button(rect, lvl["name"], font=FONT_M))
        self.back_button = Button((30, 30, 140, 40), "< Назад", font=FONT_S)

    # ------------------------------------------------------------------
    async def run(self):
        running = True
        while running:
            dt = self.clock.tick(S.FPS) / 1000.0
            mouse_pos = pygame.mouse.get_pos()
            click = False
            enter_pressed = False

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    click = True
                elif event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    enter_pressed = True

                if self.state == "playing" and self.level is not None:
                    self.level.handle_event(event)

            if self.state == "menu":
                self._update_menu(mouse_pos, click)
            elif self.state == "level_select":
                self._update_level_select(mouse_pos, click)
            elif self.state == "playing":
                self.level.update(dt)
                if self.level.state in ("won", "lost") and enter_pressed:
                    self.state = "menu"
                    self.level = None

            self._draw()
            pygame.display.flip()
            await asyncio.sleep(0)
        pygame.quit()
        sys.exit(0)

    # ------------------------------------------------------------------
    def _update_menu(self, mouse_pos, click):
        for b in self.menu_buttons:
            b.update(mouse_pos)
        if self.menu_buttons[0].clicked(mouse_pos, click):
            self.state = "level_select"
        elif self.menu_buttons[1].clicked(mouse_pos, click):
            self.level = Level(self.screen, endless=True)
            self.state = "playing"
        elif self.menu_buttons[2].clicked(mouse_pos, click):
            pygame.quit()
            sys.exit(0)

    def _update_level_select(self, mouse_pos, click):
        self.back_button.update(mouse_pos)
        if self.back_button.clicked(mouse_pos, click):
            self.state = "menu"
            return
        for i, b in enumerate(self.level_buttons):
            b.update(mouse_pos)
            if b.clicked(mouse_pos, click):
                self.level = Level(self.screen, level_def=CAMPAIGN_LEVELS[i])
                self.state = "playing"
                return

    # ------------------------------------------------------------------
    def _draw(self):
        if self.state == "menu":
            self._draw_menu()
        elif self.state == "level_select":
            self._draw_level_select()
        elif self.state == "playing":
            self.level.draw()

    def _draw_menu(self):
        self.screen.fill(S.COLOR_BG)
        cx = S.SCREEN_WIDTH // 2
        draw_text(self.screen, "TOWER DEFENSE", (cx, 150), FONT_XL, S.COLOR_GOLD, center=True, shadow=True)
        draw_text(self.screen, "Захищай дорогу, качай вежі за трьома гілками, виживай",
                  (cx, 200), FONT_S, S.COLOR_TEXT_DIM, center=True)
        for b in self.menu_buttons:
            b.draw(self.screen)

    def _draw_level_select(self):
        self.screen.fill(S.COLOR_BG)
        cx = S.SCREEN_WIDTH // 2
        draw_text(self.screen, "Вибір рівня", (cx, 110), FONT_L, S.COLOR_TEXT, center=True)
        for b in self.level_buttons:
            b.draw(self.screen)
        self.back_button.draw(self.screen)



if __name__ == "__main__":
    asyncio.run(App().run())
    