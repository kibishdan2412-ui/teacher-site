# -*- coding: utf-8 -*-
"""Вороги: базовий клас + характеристики типів + фабрика створення."""
import math

ENEMY_BASE = {
    "normal": dict(hp=50, speed=62, armor=0, reward=10, radius=13,
                   color=(190, 190, 190), flying=False, name="Піхота"),
    "fast": dict(hp=28, speed=135, armor=0, reward=11, radius=10,
                 color=(240, 220, 70), flying=False, name="Бігун"),
    "tank": dict(hp=180, speed=38, armor=6, reward=22, radius=17,
                 color=(150, 40, 40), flying=False, name="Танк"),  # нерф
    "flying": dict(hp=65, speed=95, armor=0, reward=16, radius=11,
                   color=(110, 190, 240), flying=True, name="Летун"),
    "swarm": dict(hp=14, speed=105, armor=0, reward=4, radius=8,
                  color=(140, 230, 140), flying=False, name="Рій"),
    "boss": dict(hp=1200, speed=34, armor=10, reward=150, radius=26,
                 color=(170, 70, 200), flying=False, name="Бос"),  # нерф
    "armored": dict(hp=220, speed=42, armor=14, reward=30, radius=18,
                    color=(180, 180, 180), flying=False, name="Броньовик",
                    resist_physical=True, weak_fire=True, weak_aura=True),  # нерф
    "splitter": dict(hp=60, speed=58, armor=3, reward=16, radius=14,
                     color=(200, 100, 100), flying=False, name="Роздільник",
                     split_count=4, split_hp=15, split_speed=100),  # нерф
}

ENEMY_ORDER = ["normal", "fast", "tank", "flying", "swarm", "boss", "armored", "splitter"]


class Enemy:
    def __init__(self, kind, path, scale=1.0):
        base = ENEMY_BASE[kind]
        self.kind = kind
        self.name = base["name"]
        self.path = path
        self.path_index = 1
        self.x, self.y = path[0]

        hp_scale = scale
        speed_scale = 1.0 + (scale - 1.0) * 0.18
        self.max_hp = base["hp"] * hp_scale
        self.hp = self.max_hp
        self.base_speed = base["speed"] * speed_scale
        self.armor = base["armor"] * (1.0 + (scale - 1.0) * 0.35)
        self.reward = int(base["reward"] * (0.55 + 0.45 * math.sqrt(scale)))
        self.radius = base["radius"]
        self.color = base["color"]
        self.is_flying = base["flying"]

        self.resist_physical = base.get("resist_physical", False)
        self.weak_fire = base.get("weak_fire", False)
        self.weak_aura = base.get("weak_aura", False)
        self.split_count = base.get("split_count", 0)
        self.split_hp = base.get("split_hp", 0)
        self.split_speed = base.get("split_speed", 0)
        self.is_split = False

        self.alive = True
        self.reached_end = False

        self.slow_timer = 0.0
        self.slow_factor = 1.0
        self.root_timer = 0.0
        self.burn_timer = 0.0
        self.burn_dps = 0.0
        self.armor_reduce = 0.0
        self.armor_reduce_timer = 0.0

        self.hit_flash = 0.0

    def apply_slow(self, factor, duration):
        if factor < self.slow_factor or self.slow_timer <= 0:
            self.slow_factor = factor
        self.slow_timer = max(self.slow_timer, duration)

    def apply_root(self, duration):
        self.root_timer = max(self.root_timer, duration)

    def apply_burn(self, dps, duration):
        self.burn_dps = max(self.burn_dps, dps)
        self.burn_timer = max(self.burn_timer, duration)

    def apply_armor_reduce(self, amount, duration):
        self.armor_reduce = max(self.armor_reduce, amount)
        self.armor_reduce_timer = max(self.armor_reduce_timer, duration)

    def effective_armor(self):
        return max(0.0, self.armor - self.armor_reduce)

    def take_damage(self, dmg, armor_pierce=0.0, damage_type="physical"):
        armor = self.effective_armor() * (1.0 - armor_pierce)

        if damage_type == "physical" and self.resist_physical:
            armor += 12

        if damage_type == "fire" and self.weak_fire:
            dmg *= 1.8

        if damage_type == "aura" and self.weak_aura:
            dmg *= 1.6

        actual = max(1.0, dmg - armor)
        self.hp -= actual
        self.hit_flash = 0.08
        if self.hp <= 0:
            self.alive = False
        return actual

    def split(self, path):
        if self.split_count > 0 and not self.is_split:
            children = []
            for i in range(self.split_count):
                child = Enemy("splitter", path, scale=0.4)
                child.max_hp = self.split_hp
                child.hp = self.split_hp
                child.base_speed = self.split_speed
                child.radius = 5
                child.color = (220, 140, 140)
                child.reward = 2
                child.is_split = True
                angle = i * (2 * math.pi / self.split_count)
                child.x = self.x + math.cos(angle) * 12
                child.y = self.y + math.sin(angle) * 12
                child.path_index = self.path_index
                children.append(child)
            return children
        return []

    def update(self, dt):
        if not self.alive:
            return
        if self.burn_timer > 0:
            self.hp -= self.burn_dps * dt
            self.burn_timer -= dt
            self.hit_flash = 0.05
            if self.hp <= 0:
                self.alive = False
                return
        if self.armor_reduce_timer > 0:
            self.armor_reduce_timer -= dt
            if self.armor_reduce_timer <= 0:
                self.armor_reduce = 0.0
        if self.hit_flash > 0:
            self.hit_flash -= dt

        speed = self.base_speed
        if self.root_timer > 0:
            self.root_timer -= dt
            speed = 0
        elif self.slow_timer > 0:
            self.slow_timer -= dt
            speed *= self.slow_factor
            if self.slow_timer <= 0:
                self.slow_factor = 1.0

        if speed <= 0:
            return

        if self.path_index >= len(self.path):
            self.reached_end = True
            self.alive = False
            return

        tx, ty = self.path[self.path_index]
        dx, dy = tx - self.x, ty - self.y
        dist = math.hypot(dx, dy)
        move = speed * dt
        if dist <= move:
            self.x, self.y = tx, ty
            self.path_index += 1
            if self.path_index >= len(self.path):
                self.reached_end = True
                self.alive = False
        else:
            self.x += dx / dist * move
            self.y += dy / dist * move

    def progress(self):
        return self.path_index * 100000 - math.hypot(
            self.x - self.path[min(self.path_index, len(self.path) - 1)][0],
            self.y - self.path[min(self.path_index, len(self.path) - 1)][1],
        )


def create_enemy(kind, path, scale=1.0):
    return Enemy(kind, path, scale)