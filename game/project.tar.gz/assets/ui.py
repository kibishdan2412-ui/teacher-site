# -*- coding: utf-8 -*-
"""Прості перевикористовувані UI-віджети (кнопки, текст, прогрес-бари)."""
import pygame
import settings as S

pygame.font.init()
FONT_S = pygame.font.SysFont("arial", 14)
FONT_M = pygame.font.SysFont("arial", 18)
FONT_L = pygame.font.SysFont("arial", 26, bold=True)
FONT_XL = pygame.font.SysFont("arial", 40, bold=True)


def draw_text(surf, text, pos, font=FONT_M, color=S.COLOR_TEXT, center=False, shadow=False):
    if shadow:
        sh = font.render(text, True, (0, 0, 0))
        r = sh.get_rect()
        if center:
            r.center = (pos[0] + 1, pos[1] + 1)
        else:
            r.topleft = (pos[0] + 1, pos[1] + 1)
        surf.blit(sh, r)
    img = font.render(text, True, color)
    r = img.get_rect()
    if center:
        r.center = pos
    else:
        r.topleft = pos
    surf.blit(img, r)
    return r


class Button:
    def __init__(self, rect, text, font=FONT_M, bg=S.COLOR_PANEL,
                 bg_hover=S.COLOR_PANEL_LIGHT, fg=S.COLOR_TEXT, enabled=True,
                 border=None):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.font = font
        self.bg = bg
        self.bg_hover = bg_hover
        self.fg = fg
        self.enabled = enabled
        self.border = border
        self.hovered = False

    def update(self, mouse_pos):
        self.hovered = self.enabled and self.rect.collidepoint(mouse_pos)

    def clicked(self, mouse_pos, mouse_click):
        return self.enabled and mouse_click and self.rect.collidepoint(mouse_pos)

    def draw(self, surf):
        color = self.bg_hover if self.hovered else self.bg
        if not self.enabled:
            color = (35, 35, 42)
        pygame.draw.rect(surf, color, self.rect, border_radius=6)
        border_color = self.border or (90, 90, 105)
        pygame.draw.rect(surf, border_color, self.rect, width=1, border_radius=6)
        fg = self.fg if self.enabled else S.COLOR_TEXT_DIM
        draw_text(surf, self.text, self.rect.center, self.font, fg, center=True)


def draw_bar(surf, x, y, w, h, ratio, fg_color, bg_color=(40, 40, 40)):
    ratio = max(0.0, min(1.0, ratio))
    pygame.draw.rect(surf, bg_color, (x, y, w, h), border_radius=3)
    if ratio > 0:
        pygame.draw.rect(surf, fg_color, (x, y, int(w * ratio), h), border_radius=3)
    pygame.draw.rect(surf, (10, 10, 10), (x, y, w, h), width=1, border_radius=3)