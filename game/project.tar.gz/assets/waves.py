# -*- coding: utf-8 -*-
"""Шляхи ворогів, хвилі та описи рівнів кампанії + безперервний режим."""

PATH_1 = [(-30, 120), (700, 120), (700, 320), (120, 320), (120, 520), (880, 520)]
PATH_2 = [(-30, 650), (200, 650), (200, 150), (450, 150), (450, 600), (700, 600), (700, 80), (880, 80)]
PATH_3 = [(-30, 80), (780, 80), (780, 280), (80, 280), (80, 480), (780, 480), (780, 680), (880, 680)]
PATH_4 = [(-30, 375), (400, 375), (400, 80), (780, 80), (780, 650), (150, 650), (150, 200), (880, 200)]
PATH_5 = [(-30, 650), (150, 650), (150, 80), (350, 80), (350, 600), (550, 600), (550, 120), (750, 120), (750, 550), (880, 550)]

ENDLESS_PATH = PATH_3


def wave(enemies_list, interval=0.6, scale=1.0, delay=3.0):
    return dict(enemies=list(enemies_list), interval=interval, scale=scale, delay=delay)


def _rep(kind, n):
    return [kind] * n


CAMPAIGN_LEVELS = [
    dict(
        name="Рівень 1: Перша лінія",
        path=PATH_1,
        start_money=300,
        start_lives=20,
        waves=[
            wave(_rep("normal", 6), interval=0.8, scale=1.0, delay=1.0),
            wave(_rep("normal", 8) + _rep("fast", 4), interval=0.65, scale=1.15),
            wave(_rep("fast", 8) + _rep("normal", 6), interval=0.55, scale=1.3),
            wave(_rep("normal", 10) + _rep("tank", 2), interval=0.55, scale=1.5),
            wave(_rep("tank", 3) + _rep("normal", 10) + _rep("fast", 6), interval=0.5, scale=1.75),
        ],
    ),
    dict(
        name="Рівень 2: Повітряна тривога",
        path=PATH_2,
        start_money=340,
        start_lives=20,
        waves=[
            wave(_rep("normal", 8) + _rep("flying", 3), interval=0.6, scale=1.3, delay=1.0),
            wave(_rep("fast", 8) + _rep("flying", 5), interval=0.55, scale=1.5),
            wave(_rep("swarm", 14) + _rep("flying", 4), interval=0.35, scale=1.6),
            wave(_rep("tank", 4) + _rep("flying", 6) + _rep("normal", 8), interval=0.5, scale=1.9),
            wave(_rep("flying", 10) + _rep("fast", 10) + _rep("tank", 3), interval=0.45, scale=2.1),
        ],
    ),
    dict(
        name="Рівень 3: Стіна та рій",
        path=PATH_3,
        start_money=380,
        start_lives=18,
        waves=[
            wave(_rep("normal", 10) + _rep("swarm", 10) + _rep("splitter", 1), interval=0.5, scale=1.6, delay=1.0),
            wave(_rep("tank", 5) + _rep("fast", 8) + _rep("armored", 1), interval=0.5, scale=1.9),
            wave(_rep("swarm", 20) + _rep("flying", 6) + _rep("splitter", 2), interval=0.3, scale=2.0),
            wave(_rep("tank", 6) + _rep("normal", 10) + _rep("flying", 6) + _rep("armored", 2), interval=0.45, scale=2.3),
            wave(_rep("boss", 1) + _rep("swarm", 16) + _rep("tank", 4) + _rep("splitter", 3), interval=0.4, scale=2.4),
        ],
    ),
    dict(
        name="Рівень 4: Бронеколона",
        path=PATH_4,
        start_money=420,
        start_lives=18,
        waves=[
            wave(_rep("tank", 6) + _rep("normal", 10) + _rep("armored", 2), interval=0.5, scale=2.0, delay=1.0),
            wave(_rep("fast", 12) + _rep("tank", 5) + _rep("splitter", 2), interval=0.45, scale=2.2),
            wave(_rep("swarm", 22) + _rep("flying", 8) + _rep("armored", 3), interval=0.3, scale=2.4),
            wave(_rep("tank", 8) + _rep("flying", 8) + _rep("fast", 8) + _rep("splitter", 3), interval=0.4, scale=2.7),
            wave(_rep("boss", 2) + _rep("tank", 6) + _rep("normal", 12) + _rep("armored", 4), interval=0.4, scale=2.8),
        ],
    ),
    dict(
        name="Рівень 5: Фінальний штурм",
        path=PATH_5,
        start_money=470,
        start_lives=16,
        waves=[
            wave(_rep("tank", 8) + _rep("swarm", 14) + _rep("armored", 3) + _rep("splitter", 2), interval=0.45, scale=2.4, delay=1.0),
            wave(_rep("flying", 14) + _rep("fast", 12) + _rep("armored", 4) + _rep("splitter", 3), interval=0.4, scale=2.7),
            wave(_rep("swarm", 26) + _rep("tank", 6) + _rep("splitter", 4) + _rep("armored", 3), interval=0.28, scale=2.9),
            wave(_rep("boss", 2) + _rep("flying", 10) + _rep("fast", 10) + _rep("armored", 5), interval=0.4, scale=3.1),
            wave(_rep("boss", 3) + _rep("tank", 10) + _rep("swarm", 20) + _rep("flying", 10) + _rep("armored", 6) + _rep("splitter", 5),
                 interval=0.35, scale=3.4),
        ],
    ),
]


def generate_endless_wave(wave_number):
    from settings import ENDLESS_SCALE_PER_WAVE, ENDLESS_BOSS_EVERY
    scale = 1.0 + (wave_number - 1) * ENDLESS_SCALE_PER_WAVE
    n = wave_number
    enemies = []
    enemies += _rep("normal", 6 + n // 2)
    enemies += _rep("fast", 3 + n // 2)
    if n >= 2:
        enemies += _rep("tank", 1 + n // 3)
    if n >= 3:
        enemies += _rep("flying", 2 + n // 3)
    if n >= 4:
        enemies += _rep("swarm", 6 + n)
    if n >= 5:
        enemies += _rep("armored", 1 + n // 4)
    if n >= 6:
        enemies += _rep("splitter", 1 + n // 5)
    if n % ENDLESS_BOSS_EVERY == 0:
        enemies += _rep("boss", 1 + n // (ENDLESS_BOSS_EVERY * 3))
    interval = max(0.18, 0.6 - n * 0.012)
    return wave(enemies, interval=interval, scale=scale, delay=2.0)