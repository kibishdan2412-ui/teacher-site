# -*- coding: utf-8 -*-
"""Снаряди, що летять від веж до цілей."""
import math
import random
import pygame
import settings as S


class Projectile:
    def __init__(self, x, y, target, damage, speed, color,
                 splash_radius=0.0, armor_pierce=0.0,
                 slow=None, burn=None, root_chance=0.0, root_duration=0.0,
                 armor_reduce=None, pierce_count=1, bonus_tags=None,
                 explode_on_death=False, chain_bonus=0.0, radius=4):
        self.x, self.y = x, y
        self.target = target
        self.damage = damage
        self.speed = speed
        self.color = color
        self.splash_radius = splash_radius
        self.armor_pierce = armor_pierce
        self.slow = slow
        self.burn = burn
        self.root_chance = root_chance
        self.root_duration = root_duration
        self.armor_reduce = armor_reduce
        self.pierce_count = pierce_count
        self.hit_targets = set()
        self.bonus_tags = bonus_tags or {}
        self.explode_on_death = explode_on_death
        self.chain_bonus = chain_bonus
        self.radius = radius
        self.alive = True
        self.trail = []

        # спеціальні властивості для візуалізації
        self.is_laser = False
        self.laser_target = None
        self.laser_timer = 0.1  # час життя променя
        self.is_chain = False
        self.chain_targets = []
        self.chain_timer = 0.3

    def _damage_with_bonus(self, enemy):
        dmg = self.damage
        mult = self.bonus_tags.get(enemy.kind, 1.0)
        return dmg * mult

    def _apply_effects(self, enemy):
        if self.slow:
            enemy.apply_slow(*self.slow)
        if self.burn:
            enemy.apply_burn(*self.burn)
        if self.armor_reduce:
            enemy.apply_armor_reduce(*self.armor_reduce)
        if self.root_chance > 0:
            if random.random() < self.root_chance:
                enemy.apply_root(self.root_duration)

    def _hit(self, enemy, all_enemies, money_add_cb=None):
        if enemy in self.hit_targets:
            return
        self.hit_targets.add(enemy)
        dmg = self._damage_with_bonus(enemy)
        was_alive = enemy.alive
        enemy.take_damage(dmg, armor_pierce=self.armor_pierce)
        self._apply_effects(enemy)
        if was_alive and not enemy.alive and money_add_cb:
            money_add_cb(enemy.reward)

        if self.splash_radius > 0:
            hit_count = 0
            for other in all_enemies:
                if other is enemy or not other.alive:
                    continue
                d = math.hypot(other.x - enemy.x, other.y - enemy.y)
                if d <= self.splash_radius:
                    extra_dmg = self._damage_with_bonus(other) + hit_count * self.chain_bonus
                    other_was_alive = other.alive
                    other.take_damage(extra_dmg, armor_pierce=self.armor_pierce)
                    self._apply_effects(other)
                    if other_was_alive and not other.alive and money_add_cb:
                        money_add_cb(other.reward)
                    hit_count += 1

        if self.explode_on_death and was_alive and not enemy.alive:
            for other in all_enemies:
                if other is enemy or not other.alive or other in self.hit_targets:
                    continue
                d = math.hypot(other.x - enemy.x, other.y - enemy.y)
                if d <= max(self.splash_radius, 40) * 1.3:
                    self.hit_targets.add(other)
                    other_was_alive = other.alive
                    other.take_damage(self.damage * 0.5, armor_pierce=self.armor_pierce)
                    self._apply_effects(other)
                    if other_was_alive and not other.alive and money_add_cb:
                        money_add_cb(other.reward)

    def update(self, dt, all_enemies, money_add_cb=None):
        if not self.alive:
            # для променя - таймер життя
            if self.is_laser:
                self.laser_timer -= dt
                if self.laser_timer <= 0:
                    return False
                # оновлюємо позицію променя до цілі
                if self.laser_target and self.laser_target.alive:
                    return True
                return False
            # для ланцюгової блискавки - таймер життя
            if self.is_chain:
                self.chain_timer -= dt
                if self.chain_timer <= 0:
                    return False
                return True
            return False

        if self.target is not None and not self.target.alive:
            aim_x, aim_y = self.target.x, self.target.y
            target_ref = None
        else:
            target_ref = self.target
            aim_x, aim_y = (target_ref.x, target_ref.y) if target_ref else (self.x, self.y)

        dx, dy = aim_x - self.x, aim_y - self.y
        dist = math.hypot(dx, dy)
        move = self.speed * dt
        self.trail.append((self.x, self.y))
        if len(self.trail) > 4:
            self.trail.pop(0)

        if dist <= max(move, 6):
            self.x, self.y = aim_x, aim_y
            if target_ref is not None and target_ref.alive:
                self._hit(target_ref, all_enemies, money_add_cb)
            if self.pierce_count > len(self.hit_targets):
                for other in all_enemies:
                    if len(self.hit_targets) >= self.pierce_count:
                        break
                    if not other.alive or other in self.hit_targets:
                        continue
                    d = math.hypot(other.x - self.x, other.y - self.y)
                    if d <= 26:
                        self._hit(other, all_enemies, money_add_cb)
            self.alive = False
            return False
        else:
            self.x += dx / dist * move
            self.y += dy / dist * move
        return True

    def draw(self, surf):
        # Промінь вогню (піро) - спрощена оптимізована версія
        if self.is_laser and self.laser_target and self.laser_target.alive:
            x1, y1 = int(self.x), int(self.y)
            x2, y2 = int(self.laser_target.x), int(self.laser_target.y)
            # тільки один простий промінь + яскрава лінія
            pygame.draw.line(surf, (255, 80, 20), (x1, y1), (x2, y2), 4)
            pygame.draw.line(surf, (255, 200, 50), (x1, y1), (x2, y2), 1)
            return

        # Ланцюгова блискавка (громовержець)
        if self.is_chain and self.chain_targets:
            prev = (self.x, self.y)
            for i, target in enumerate(self.chain_targets):
                if not target.alive:
                    continue
                x1, y1 = prev
                x2, y2 = target.x, target.y
                # простий зигзаг без зайвих обчислень
                mid_x = (x1 + x2) / 2 + (random.random() - 0.5) * 20
                mid_y = (y1 + y2) / 2 + (random.random() - 0.5) * 20
                brightness = 200 - i * 40
                line_width = max(1, int(3 - i * 0.5))
                pygame.draw.line(surf, (brightness, brightness, 255), (x1, y1), (mid_x, mid_y), line_width)
                pygame.draw.line(surf, (brightness, brightness, 255), (mid_x, mid_y), (x2, y2), line_width)
                pygame.draw.circle(surf, (200, 220, 255), (int(x2), int(y2)), max(1, int(4 - i)))
                prev = (x2, y2)
            return

        # звичайний снаряд
        for i, (tx, ty) in enumerate(self.trail):
            a = int(120 * (i + 1) / (len(self.trail) + 1))
            s = pygame.Surface((6, 6), pygame.SRCALPHA)
            pygame.draw.circle(s, (*self.color, a), (3, 3), 2)
            surf.blit(s, (tx - 3, ty - 3))
        pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), self.radius)