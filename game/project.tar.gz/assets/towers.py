# -*- coding: utf-8 -*-
"""Вежі та їхні дерева прокачування."""
from random import random


import math
from projectiles import Projectile

ATTACK_TOWERS = {"basic", "sniper", "aura", "pyro", "glue", "demoman", "engineer", "thunderer"}
SUPPORT_TOWERS = {"support"}

TOWER_BASE = {
    "basic": dict(
        name="Звичайна вежа", cost=100, range=150, damage=20, fire_rate=1.0,
        proj_speed=420, splash=0, pierce=1, can_hit_flying=False,
        color=(120, 170, 230), desc="Універсальна вежа. Стріляє по одному ворогу.",
    ),
    "sniper": dict(
        name="Снайпер", cost=140, range=350, damage=45, fire_rate=0.5,
        proj_speed=900, splash=0, pierce=1, can_hit_flying=True,
        color=(210, 210, 90), desc="Велика дальність і урон, але тепер слабший на початку.",
    ),
    "aura": dict(
        name="Аура-вежа", cost=130, range=100, damage=8, fire_rate=2.0,
        proj_speed=0, splash=0, pierce=99, can_hit_flying=False,
        color=(180, 90, 220), desc="Б'є імпульсом по всіх ворогах навколо.",
    ),
    "support": dict(
        name="Роздатчик", cost=120, range=130, damage=0, fire_rate=0,
        proj_speed=0, splash=0, pierce=0, can_hit_flying=False,
        color=(240, 200, 90), desc="Покращує особливість вежі в радіусі.",
    ),
    "pyro": dict(
        name="Піро-вежа", cost=130, range=130, damage=6, fire_rate=4.0,
        proj_speed=0, splash=0, pierce=0, can_hit_flying=False,
        color=(255, 80, 20), desc="Б'є променем вогню. Бачить лише наземних.",
    ),
    "glue": dict(
        name="Клейка вежа", cost=100, range=150, damage=8, fire_rate=1.2,
        proj_speed=420, splash=0, pierce=1, can_hit_flying=True,
        color=(90, 210, 190), desc="Сповільнює та завдає середнього урону. Б'є всіх.",
    ),
    "demoman": dict(
        name="Демомен", cost=140, range=160, damage=0, fire_rate=0,
        proj_speed=0, splash=0, pierce=0, can_hit_flying=False,
        color=(200, 80, 30), desc="Кожну секунду ставить міну на дорозі (до 10). Б'є лише наземних.",
    ),
    "engineer": dict(
        name="Інженер", cost=150, range=180, damage=0, fire_rate=0,
        proj_speed=0, splash=0, pierce=0, can_hit_flying=False,
        color=(255, 200, 50), desc="Ставить турелі на платформі (до 8). Б'є лише наземних.",
    ),
    "thunderer": dict(
        name="Громовержець", cost=160, range=180, damage=20, fire_rate=0.8,
        proj_speed=0, splash=0, pierce=0, can_hit_flying=False,
        color=(100, 200, 255), desc="Б'є електрикою, що перескакує між ворогами. Урон падає з кожним.",
    ),
}

TOWER_TREES = {
    "basic": {
        "A": [
            dict(cost=90, title="Важкі снаряди", desc="+15 урону, 30% ігнору броні.",
                 mods=dict(damage_add=15, armor_pierce=0.3)),
            dict(cost=140, title="Калені сердечники", desc="+25 урону, 60% ігнору броні.",
                 mods=dict(damage_add=25, armor_pierce=0.6)),
            dict(cost=230, title="Облогова гармата", desc="+50 урону, повний ігнор броні, оглушення.",
                 mods=dict(damage_add=50, armor_pierce=1.0, root_chance=0.12, root_duration=0.35)),
        ],
        "B": [
            dict(cost=90, title="Подвійний магазин", desc="+0.5 скорострільності, пробиває 2 цілі.",
                 mods=dict(fire_rate_add=0.5, pierce_set=2)),
            dict(cost=140, title="Прискорений привід", desc="Скорострільність 2.2/с, пробиває 3 цілі.",
                 mods=dict(fire_rate_add=1.2, pierce_set=3)),
            dict(cost=230, title="Гатлінг", desc="Скорострільність 3.5/с, пробиває 5 цілей, малий сплеш.",
                 mods=dict(fire_rate_add=2.5, pierce_set=5, splash_set=20)),
        ],
        "C": [
            dict(cost=90, title="Оптика", desc="+60 дальності, може бити літаючих.",
                 mods=dict(range_add=60, can_hit_flying=True)),
            dict(cost=140, title="Підсилений ствол", desc="+100 дальності, +10 урону.",
                 mods=dict(range_add=100, damage_add=10)),
            dict(cost=230, title="Дозорна вежа", desc="+160 дальності, x1.5 урон по летунах/бігунах.",
                 mods=dict(range_add=160, bonus_tags={"flying": 1.5, "fast": 1.5})),
        ],
    },
    "sniper": {
        "A": [
            dict(cost=110, title="Бронебійний", desc="+15 урону, 40% ігнору броні.",
                 mods=dict(damage_add=15, armor_pierce=0.4)),
            dict(cost=170, title="Вольфрамовий", desc="+25 урону, 80% ігнору броні.",
                 mods=dict(damage_add=25, armor_pierce=0.8)),
            dict(cost=270, title="Розривний", desc="+40 урону, повний ігнор броні.",
                 mods=dict(damage_add=40, armor_pierce=1.0)),
        ],
        "B": [
            dict(cost=110, title="Прицільний", desc="15% шанс x3 урону.",
                 mods=dict(crit_chance=0.15, crit_mult=3.0)),
            dict(cost=170, title="Слабке місце", desc="25% шанс x3.5 урону, +30% по босах.",
                 mods=dict(crit_chance=0.25, crit_mult=3.5, bonus_tags={"boss": 1.3})),
            dict(cost=270, title="Точка страти", desc="35% шанс x4 урону, добивання HP<15%.",
                 mods=dict(crit_chance=0.35, crit_mult=4.0, execute_threshold=0.15)),
        ],
        "C": [
            dict(cost=110, title="Легкий затвор", desc="+0.3 скорострільності.",
                 mods=dict(fire_rate_add=0.3)),
            dict(cost=170, title="Автомат", desc="Скорострільність 1.1/с, пробиває 2 цілі.",
                 mods=dict(fire_rate_add=0.6, pierce_set=2)),
            dict(cost=270, title="Рой стріл", desc="Скорострільність 1.5/с, пробиває 3 цілі.",
                 mods=dict(fire_rate_add=0.9, pierce_set=3)),
        ],
    },
    "aura": {
        "A": [
            dict(cost=110, title="Перевантаження", desc="+6 урону імпульсу.",
                 mods=dict(damage_add=6)),
            dict(cost=170, title="Електро-розряд", desc="+14 урону, 50% ігнору броні.",
                 mods=dict(damage_add=14, armor_pierce=0.5)),
            dict(cost=270, title="Плазмовий шторм", desc="+27 урону, повний ігнор броні.",
                 mods=dict(damage_add=27, armor_pierce=1.0)),
        ],
        "B": [
            dict(cost=110, title="Ланцюговий шок", desc="+2 урону за ворога в аурі.",
                 mods=dict(chain_bonus=2)),
            dict(cost=170, title="Резонанс", desc="+4 урону за ворога, +1 базовий урон.",
                 mods=dict(chain_bonus=4, damage_add=1)),
            dict(cost=270, title="Каскад", desc="+7 урону за ворога, оглушення.",
                 mods=dict(chain_bonus=7, root_chance=0.08, root_duration=0.25)),
        ],
        "C": [
            dict(cost=110, title="Розширення", desc="+40 радіусу, б'є літаючих.",
                 mods=dict(range_add=40, can_hit_flying=True)),
            dict(cost=170, title="Велика котушка", desc="+80 радіусу, +4 урону.",
                 mods=dict(range_add=80, damage_add=4)),
            dict(cost=270, title="Грозова хмара", desc="+130 радіусу, імпульс кожні 0.35с.",
                 mods=dict(range_add=130, fire_rate_add=0.85, damage_add=8)),
        ],
    },
    "support": {
        "A": [
            dict(cost=100, title="Підсилення I", desc="Особливість веж поруч +25%.",
                 mods=dict(buff_special=0.25)),
            dict(cost=160, title="Підсилення II", desc="Особливість веж поруч +50%.",
                 mods=dict(buff_special=0.50)),
            dict(cost=260, title="Підсилення III", desc="Особливість веж поруч +100%.",
                 mods=dict(buff_special=1.0)),
        ],
        "B": [
            dict(cost=100, title="Прискорення I", desc="Вежі поруч +20% скорострільності.",
                 mods=dict(buff_speed=0.20)),
            dict(cost=160, title="Прискорення II", desc="+35% скорострільності.",
                 mods=dict(buff_speed=0.35)),
            dict(cost=260, title="Прискорення III", desc="+55% скорострільності.",
                 mods=dict(buff_speed=0.55)),
        ],
        "C": [
            dict(cost=100, title="Фокусування I", desc="Вежі поруч +20% дальності.",
                 mods=dict(buff_range=0.20)),
            dict(cost=160, title="Фокусування II", desc="+35% дальності.",
                 mods=dict(buff_range=0.35)),
            dict(cost=260, title="Фокусування III", desc="+50% дальності.",
                 mods=dict(buff_range=0.50)),
        ],
    },
    "pyro": {  # Додаємо дерево для піро
        "A": [  # Інферно - збільшення урону
            dict(cost=100, title="Інферно", desc="+3 урону променя.",
                 mods=dict(damage_add=3)),
            dict(cost=160, title="Палаюча куля", desc="+6 урону, +1 частота.",
                 mods=dict(damage_add=6, fire_rate_add=1.0)),
            dict(cost=250, title="Пекельне полум'я", desc="+12 урону, +2 частота, 50% ігнору броні.",
                 mods=dict(damage_add=12, fire_rate_add=2.0, armor_pierce=0.5)),
        ],
        "B": [  # Довгий промінь - збільшення дальності
            dict(cost=100, title="Довгий промінь", desc="+40 дальності.",
                 mods=dict(range_add=40)),
            dict(cost=160, title="Широкий промінь", desc="+70 дальності, +3 урону.",
                 mods=dict(range_add=70, damage_add=3)),
            dict(cost=250, title="Всепалюючий", desc="+110 дальності, +6 урону, підпал.",
                 mods=dict(range_add=110, damage_add=6, burn_dps=5, burn_dur=2)),
        ],
        "C": [  # Зір яструба - бачить летунів
            dict(cost=100, title="Зір яструба", desc="Тепер бачить літаючих.",
                 mods=dict(can_hit_flying=True)),
            dict(cost=160, title="Гостре око", desc="Бачить літаючих, +30 дальності.",
                 mods=dict(can_hit_flying=True, range_add=30)),
            dict(cost=250, title="Вогняний смерч", desc="Бачить літаючих, +60 дальності, +6 урону.",
                 mods=dict(can_hit_flying=True, range_add=60, damage_add=6)),
        ],
    },
    "glue": {
        "A": [
            dict(cost=80, title="Замороження", desc="Сповільнення 50%, 15% шанс скувати.",
                 mods=dict(slow_factor=0.5, root_chance=0.15, root_duration=0.5)),
            dict(cost=130, title="Крижані шипи", desc="Сповільнення 40%, 25% шанс скувати.",
                 mods=dict(slow_factor=0.4, root_chance=0.25, root_duration=0.8)),
            dict(cost=200, title="Абсолютний нуль", desc="Сповільнення 30%, 40% шанс скувати.",
                 mods=dict(slow_factor=0.3, root_chance=0.40, root_duration=1.2)),
        ],
        "B": [
            dict(cost=80, title="Кислота", desc="Знижує броню на 3, +3 урону.",
                 mods=dict(armor_reduce=3, armor_reduce_dur=3, damage_add=3)),
            dict(cost=130, title="Їдка слиз", desc="Знижує броню на 5, +6 урону.",
                 mods=dict(armor_reduce=5, armor_reduce_dur=4, damage_add=6)),
            dict(cost=200, title="Розчинник", desc="Знижує броню на 8, +10 урону.",
                 mods=dict(armor_reduce=8, armor_reduce_dur=5, damage_add=10)),
        ],
        "C": [
            dict(cost=80, title="Липка нитка", desc="+50 дальності, сповільнення сильніше.",
                 mods=dict(range_add=50, slow_factor=0.5)),
            dict(cost=130, title="Павутина", desc="+90 дальності, сповільнення 45%.",
                 mods=dict(range_add=90, slow_factor=0.45)),
            dict(cost=200, title="Кокон", desc="+130 дальності, +8 урону, сповільнення 40%.",
                 mods=dict(range_add=130, damage_add=8, slow_factor=0.4)),
        ],
    },
    "demoman": {
        "A": [
            dict(cost=100, title="Потужна міна", desc="+20 урону від мін.",
                 mods=dict(mine_damage=20)),
            dict(cost=160, title="Важка міна", desc="+40 урону від мін.",
                 mods=dict(mine_damage=40)),
            dict(cost=250, title="Ядерна міна", desc="+70 урону від мін, +30 сплеш.",
                 mods=dict(mine_damage=70, mine_splash=30)),
        ],
        "B": [
            dict(cost=100, title="Більше мін", desc="+2 до ліміту мін.",
                 mods=dict(mine_limit=2)),
            dict(cost=160, title="Склад мін", desc="+4 до ліміту мін.",
                 mods=dict(mine_limit=4)),
            dict(cost=250, title="Арсенал", desc="+6 до ліміту мін.",
                 mods=dict(mine_limit=6)),
        ],
        "C": [
            dict(cost=100, title="Дальня міна", desc="+40 дальності встановлення.",
                 mods=dict(mine_range=40)),
            dict(cost=160, title="Далекобійна міна", desc="+80 дальності.",
                 mods=dict(mine_range=80)),
            dict(cost=250, title="Снайперська міна", desc="+130 дальності, +10 урону.",
                 mods=dict(mine_range=130, mine_damage=10)),
        ],
    },
    "engineer": {
        "A": [
            dict(cost=80, title="Швидка турель", desc="Турелі стріляють на 30% частіше.",
                 mods=dict(turret_speed=0.30)),
            dict(cost=130, title="Прискорена турель", desc="Турелі стріляють на 60% частіше.",
                 mods=dict(turret_speed=0.60)),
            dict(cost=200, title="Гатлінг-турель", desc="Турелі стріляють на 100% частіше.",
                 mods=dict(turret_speed=1.0)),
        ],
        "B": [
            dict(cost=80, title="Потужна турель", desc="Турелі +8 урону.",
                 mods=dict(turret_damage=8)),
            dict(cost=130, title="Важка турель", desc="Турелі +16 урону.",
                 mods=dict(turret_damage=16)),
            dict(cost=200, title="Артилерія", desc="Турелі +28 урону, +20 сплеш.",
                 mods=dict(turret_damage=28, turret_splash=20)),
        ],
        "C": [
            dict(cost=80, title="Далека турель", desc="Турелі +40 дальності.",
                 mods=dict(turret_range=40)),
            dict(cost=130, title="Снайперська турель", desc="Турелі +80 дальності.",
                 mods=dict(turret_range=80)),
            dict(cost=200, title="Дозорна турель", desc="Турелі +130 дальності.",
                 mods=dict(turret_range=130)),
        ],
    },
    "thunderer": {
        "A": [
            dict(cost=100, title="Потужний розряд", desc="+5 базового урону.",
                 mods=dict(damage_add=5)),
            dict(cost=160, title="Сильний розряд", desc="+10 базового урону.",
                 mods=dict(damage_add=10)),
            dict(cost=250, title="Громовий удар", desc="+18 базового урону, +1 перескок.",
                 mods=dict(damage_add=18, chain_count=1)),
        ],
        "B": [
            dict(cost=100, title="Довга блискавка", desc="+30 дальності.",
                 mods=dict(range_add=30)),
            dict(cost=160, title="Довга блискавка II", desc="+60 дальності.",
                 mods=dict(range_add=60)),
            dict(cost=250, title="Довга блискавка III", desc="+100 дальності.",
                 mods=dict(range_add=100)),
        ],
        "C": [
            dict(cost=100, title="Швидкий розряд", desc="+0.2 скорострільності.",
                 mods=dict(fire_rate_add=0.2)),
            dict(cost=160, title="Швидкий розряд II", desc="+0.4 скорострільності.",
                 mods=dict(fire_rate_add=0.4)),
            dict(cost=250, title="Швидкий розряд III", desc="+0.6 скорострільності.",
                 mods=dict(fire_rate_add=0.6)),
        ],
    },
}

BRANCH_NAMES = {
    "basic": {"A": "Міць (танки)", "B": "Скорострільність (рій)", "C": "Далекобійність (летуни)"},
    "sniper": {"A": "Бронебійні (танки)", "B": "Хедшот (боси)", "C": "Перезарядка (рій)"},
    "aura": {"A": "Перевантаження (танки)", "B": "Ланцюговий шок (рій)", "C": "Розширення (летуни)"},
    "support": {"A": "Підсилення особливостей", "B": "Прискорення", "C": "Фокусування (дальність)"},
    "pyro": {"A": "Інферно (урон)", "B": "Довгий промінь (дальність)", "C": "Зір яструба (летуни)"},
    "glue": {"A": "Замороження (бігуни)", "B": "Роз'їдаючий (танки)", "C": "Павутина (дальність)"},
    "demoman": {"A": "Потужні міни", "B": "Більше мін", "C": "Дальні міни"},
    "engineer": {"A": "Швидкі турелі", "B": "Потужні турелі", "C": "Далекі турелі"},
    "thunderer": {"A": "Потужний розряд", "B": "Довга блискавка", "C": "Швидкий розряд"},
}


class Tower:
    def __init__(self, kind, x, y, grid_x, grid_y):
        self.kind = kind
        self.x, self.y = x, y
        self.grid_x, self.grid_y = grid_x, grid_y
        self.base = TOWER_BASE[kind]
        self.cost = self.base["cost"]
        self.branch = None
        self.tier = 0
        self.cooldown = 0.0
        self.target = None
        self.total_spent = self.cost
        self.kills = 0
        self.damage_done = 0

        self.buff_damage = 0.0
        self.buff_speed = 0.0
        self.buff_pierce = 0.0
        self.buff_boss = 0.0
        self.buff_special = 0.0
        self.buff_range = 0.0
        self.pulse_flash = 0.0

        # Демомен
        self.mines = []
        self.mine_limit = 10
        self.mine_damage = 50
        self.mine_splash = 20
        self.mine_range = self.base["range"]
        self.mine_cooldown = 1.0
        self.path = []  # шлях для встановлення мін

        # Інженер
        self.turrets = []
        self.turret_limit = 8
        self.turret_damage = 15
        self.turret_speed = 0.8
        self.turret_range = 180
        self.turret_splash = 0

        # Громовержець
        self.chain_falloff = 0.20  # втрата урону за кожного ворога (збільшено)
        self.chain_max = 4  # максимальна кількість перескоків
        self.damage_multiplier = 1.0

        # Піро
        self.laser_angle = 0
        self.laser_target = None
        self.target_fixed = False
        self.target_lock_timer = 0.0

    def _accumulated_mods(self):
        if not self.branch or self.tier <= 0:
            return {}
        tier_def = TOWER_TREES[self.kind][self.branch][self.tier - 1]
        mods = dict(tier_def["mods"])
        if "bonus_tags" in mods:
            mods["bonus_tags"] = dict(mods["bonus_tags"])
        return mods

    def get_stats(self):
        b = self.base
        m = self._accumulated_mods()

        base_range = b["range"] + m.get("range_add", 0)
        effective_range = base_range * (1.0 + self.buff_range)

        stats = dict(
            range=effective_range,
            damage=(b["damage"] + m.get("damage_add", 0)) * (1.0 + self.buff_damage),
            fire_rate=(b["fire_rate"] + m.get("fire_rate_add", 0)) * (1.0 + self.buff_speed),
            proj_speed=b["proj_speed"],
            splash=m.get("splash_set", b["splash"] + m.get("splash_add", 0)),
            pierce=m.get("pierce_set", b["pierce"]),
            can_hit_flying=m.get("can_hit_flying", b["can_hit_flying"]),
            armor_pierce=min(1.0, m.get("armor_pierce", 0) + self.buff_pierce),
            slow_factor=m.get("slow_factor"),
            root_chance=m.get("root_chance", 0),
            root_duration=m.get("root_duration", 0),
            burn_dps=m.get("burn_dps"),
            burn_dur=m.get("burn_dur"),
            armor_reduce=m.get("armor_reduce"),
            armor_reduce_dur=m.get("armor_reduce_dur"),
            chain_bonus=m.get("chain_bonus", 0),
            crit_chance=m.get("crit_chance", 0),
            crit_mult=m.get("crit_mult", 1.0),
            execute_threshold=m.get("execute_threshold", 0),
            explode_on_death=m.get("explode_on_death", False),
            bonus_tags=dict(m.get("bonus_tags", {})),
            color=b["color"],
            mine_damage=m.get("mine_damage", 0),
            mine_limit=m.get("mine_limit", 0),
            mine_range=m.get("mine_range", 0),
            mine_splash=m.get("mine_splash", 0),
            turret_speed=m.get("turret_speed", 0),
            turret_damage=m.get("turret_damage", 0),
            turret_range=m.get("turret_range", 0),
            turret_splash=m.get("turret_splash", 0),
            chain_falloff=m.get("chain_falloff", 0.20),
            chain_count=m.get("chain_count", 0),
        )
        if self.buff_boss:
            stats["bonus_tags"]["boss"] = max(stats["bonus_tags"].get("boss", 1.0), 1.0 + self.buff_boss)
        return stats

    def upgrade_options(self):
        if self.branch is None:
            options = []
            for br in ("A", "B", "C"):
                tier_def = TOWER_TREES[self.kind][br][0]
                options.append(dict(branch=br, tier=1, cost=tier_def["cost"],
                                    title=tier_def["title"], desc=tier_def["desc"],
                                    branch_name=BRANCH_NAMES[self.kind][br]))
            return options
        elif self.tier < 3:
            tier_def = TOWER_TREES[self.kind][self.branch][self.tier]
            return [dict(branch=self.branch, tier=self.tier + 1, cost=tier_def["cost"],
                         title=tier_def["title"], desc=tier_def["desc"],
                         branch_name=BRANCH_NAMES[self.kind][self.branch])]
        return []

    def apply_upgrade(self, branch, tier):
        self.branch = branch
        self.tier = tier
        cost = TOWER_TREES[self.kind][branch][tier - 1]["cost"]
        self.total_spent += cost

        m = self._accumulated_mods()
        if self.kind == "demoman":
            self.mine_damage = 50 + m.get("mine_damage", 0)
            self.mine_limit = min(20, 10 + m.get("mine_limit", 0))
            self.mine_range = self.base["range"] + m.get("mine_range", 0)
            self.mine_splash = 20 + m.get("mine_splash", 0)
        elif self.kind == "engineer":
            self.turret_speed = 0.8 + m.get("turret_speed", 0)
            self.turret_damage = 15 + m.get("turret_damage", 0)
            self.turret_range = 180 + m.get("turret_range", 0)
            self.turret_splash = m.get("turret_splash", 0)
            for t in self.turrets:
                t["damage"] = self.turret_damage
                t["range"] = self.turret_range
                t["splash"] = self.turret_splash
        elif self.kind == "thunderer":
            self.chain_falloff = 0.20 + m.get("chain_falloff", 0)
            self.chain_max = 4 + m.get("chain_count", 0)
        return cost

    def sell_value(self):
        from settings import SELL_REFUND_RATIO
        return int(self.total_spent * SELL_REFUND_RATIO)

    def _pick_target(self, enemies, can_hit_flying=True):
        stats = self.get_stats()
        best = None
        best_progress = -1
        for e in enemies:
            if not e.alive:
                continue
            if e.is_flying and not can_hit_flying:
                continue
            d = math.hypot(e.x - self.x, e.y - self.y)
            if d <= stats["range"]:
                p = e.progress()
                if p > best_progress:
                    best_progress = p
                    best = e
        return best

    def _get_path_position(self):
        """Отримує позицію на дорозі для встановлення міни."""
        best_dist = float('inf')
        best_pos = (self.x + 30, self.y)
        if not self.path:
            return best_pos
        for i in range(len(self.path) - 1):
            x1, y1 = self.path[i]
            x2, y2 = self.path[i + 1]
            for t in [0, 0.25, 0.5, 0.75, 1]:
                px = x1 + (x2 - x1) * t
                py = y1 + (y2 - y1) * t
                d = math.hypot(px - self.x, py - self.y)
                if d < best_dist and d > 10:
                    best_dist = d
                    best_pos = (px, py)
        return best_pos

    def update(self, dt, enemies, money_add_cb):
        self.cooldown -= dt
        if self.pulse_flash > 0:
            self.pulse_flash -= dt

        if self.kind == "pyro":
            return self._update_pyro(dt, enemies, money_add_cb)
        elif self.kind == "demoman":
            return self._update_demoman(dt, enemies, money_add_cb)
        elif self.kind == "engineer":
            return self._update_engineer(dt, enemies, money_add_cb)
        elif self.kind == "thunderer":
            return self._update_thunderer(dt, enemies, money_add_cb)
        elif self.kind in ATTACK_TOWERS:
            return self._update_attacker(dt, enemies, money_add_cb)
        return None

    def _update_attacker(self, dt, enemies, money_add_cb):
        stats = self.get_stats()

        if self.target is None or not self.target.alive or \
                math.hypot(self.target.x - self.x, self.target.y - self.y) > stats["range"] or \
                (self.target.is_flying and not stats["can_hit_flying"]):
            self.target = self._pick_target(enemies, stats["can_hit_flying"])

        if self.target is None or self.cooldown > 0:
            return None

        fr = max(0.05, stats["fire_rate"])
        self.cooldown = 1.0 / fr

        if self.kind == "aura":
            self.pulse_flash = 0.15
            hit_count = 0
            for e in enemies:
                if not e.alive:
                    continue
                if e.is_flying and not stats["can_hit_flying"]:
                    continue
                d = math.hypot(e.x - self.x, e.y - self.y)
                if d <= stats["range"]:
                    dmg = stats["damage"] + hit_count * stats["chain_bonus"]
                    mult = stats["bonus_tags"].get(e.kind, 1.0)
                    was_alive = e.alive
                    e.take_damage(dmg * mult, armor_pierce=stats["armor_pierce"], damage_type="aura")
                    if stats["root_chance"] > 0:
                        if random.random() < stats["root_chance"]:
                            e.apply_root(stats["root_duration"])
                    if was_alive and not e.alive:
                        money_add_cb(e.reward)
                        self.kills += 1
                    self.damage_done += dmg
                    hit_count += 1
            return None

        import random
        dmg = stats["damage"]
        if stats["crit_chance"] and random.random() < stats["crit_chance"]:
            dmg *= stats["crit_mult"]
        if stats["execute_threshold"] and self.target.hp / max(1, self.target.max_hp) < stats["execute_threshold"]:
            dmg = self.target.hp + 999

        slow = (stats["slow_factor"], 1.4) if stats["slow_factor"] else None
        burn = (stats["burn_dps"], stats["burn_dur"]) if stats.get("burn_dps") else None
        armor_reduce = (stats["armor_reduce"], stats["armor_reduce_dur"]) if stats.get("armor_reduce") else None

        proj = Projectile(
            self.x, self.y, self.target, dmg, stats["proj_speed"], stats["color"],
            splash_radius=stats["splash"], armor_pierce=stats["armor_pierce"],
            slow=slow, burn=burn, root_chance=stats["root_chance"],
            root_duration=stats["root_duration"], armor_reduce=armor_reduce,
            pierce_count=stats["pierce"], bonus_tags=stats["bonus_tags"],
            explode_on_death=stats["explode_on_death"], chain_bonus=stats["chain_bonus"],
        )
        self.damage_done += dmg
        return proj

    def _update_pyro(self, dt, enemies, money_add_cb):
        """Піро - промінь вогню з візуалізацією."""
        stats = self.get_stats()

        # оновлюємо таймер фіксації цілі
        if self.target_fixed:
            self.target_lock_timer -= dt
            if self.target_lock_timer <= 0:
                self.target_fixed = False
                self.laser_target = None

        if self.cooldown > 0:
            return None

        # вибираємо ціль
        target = None
        for e in enemies:
            if not e.alive:
                continue
            if e.is_flying and not stats["can_hit_flying"]:
                continue
            d = math.hypot(e.x - self.x, e.y - self.y)
            if d <= stats["range"]:
                target = e
                break

        if target is None:
            self.laser_target = None
            self.target_fixed = False
            return None

        # якщо є зафіксована ціль і вона жива - продовжуємо бити її
        if self.target_fixed and self.laser_target and self.laser_target.alive:
            target = self.laser_target
        else:
            self.laser_target = target
            self.target_fixed = True
            self.target_lock_timer = 1.5  # фіксуємо ціль на 1.5 секунди

        fr = max(0.05, stats["fire_rate"])
        self.cooldown = 1.0 / fr

        dmg = stats["damage"]
        if stats.get("burn_dps"):
            target.apply_burn(stats["burn_dps"], stats["burn_dur"])

        was_alive = target.alive
        target.take_damage(dmg, armor_pierce=stats["armor_pierce"], damage_type="fire")
        if was_alive and not target.alive:
            money_add_cb(target.reward)
            self.kills += 1
            self.target_fixed = False
            self.laser_target = None
        self.damage_done += dmg

        # Створюємо снаряд для візуалізації променя (тільки якщо ціль жива)
        if target.alive:
            proj = Projectile(
                self.x, self.y, target, dmg, 0, (255, 150, 50),
                splash_radius=0, armor_pierce=stats["armor_pierce"],
            )
            proj.alive = False
            proj.is_laser = True
            proj.laser_target = target
            return proj
        return None

    def _update_demoman(self, dt, enemies, money_add_cb):
        """Демомен ставить міни на дорозі. Міни б'ють тільки наземних."""
        self.mine_cooldown -= dt

        # перевіряємо детонацію мін (тільки наземні вороги)
        for mine in self.mines[:]:
            for e in enemies:
                if not e.alive or e.is_flying:  # ігноруємо летунів
                    continue
                d = math.hypot(e.x - mine["x"], e.y - mine["y"])
                if d < 20:
                    # детонація
                    dmg = mine["damage"]
                    splash = mine["splash"]
                    for e2 in enemies:
                        if not e2.alive or e2.is_flying:  # ігноруємо летунів
                            continue
                        d2 = math.hypot(e2.x - mine["x"], e2.y - mine["y"])
                        if d2 <= splash:
                            was_alive = e2.alive
                            e2.take_damage(dmg * (1 - d2 / splash * 0.5), damage_type="physical")
                            if was_alive and not e2.alive:
                                money_add_cb(e2.reward)
                                self.kills += 1
                    self.mines.remove(mine)
                    self.damage_done += dmg
                    break

        # ставимо нову міну на дорозі
        if self.mine_cooldown <= 0 and len(self.mines) < self.mine_limit:
            px, py = self._get_path_position()
            too_close = False
            for mine in self.mines:
                if math.hypot(mine["x"] - px, mine["y"] - py) < 30:
                    too_close = True
                    break
            if not too_close:
                self.mines.append({
                    "x": px,
                    "y": py,
                    "damage": self.mine_damage,
                    "splash": self.mine_splash,
                })
                self.mine_cooldown = 1.0
        return None

    def _update_engineer(self, dt, enemies, money_add_cb):
        """Інженер - турелі на платформі, б'ють лише наземних."""
        for i in range(len(self.turrets)):
            self.turrets[i]["cooldown"] -= dt
            if self.turrets[i]["cooldown"] <= 0:
                turret = self.turrets[i]
                tx, ty = turret["x"], turret["y"]
                target = None
                for e in enemies:
                    if not e.alive or e.is_flying:  # ігноруємо летунів
                        continue
                    d = math.hypot(e.x - tx, e.y - ty)
                    if d <= turret["range"]:
                        target = e
                        break
                if target:
                    dmg = turret["damage"]
                    if turret.get("splash", 0) > 0:
                        for e2 in enemies:
                            if not e2.alive or e2.is_flying:
                                continue
                            d2 = math.hypot(e2.x - target.x, e2.y - target.y)
                            if d2 <= turret["splash"]:
                                was_alive = e2.alive
                                e2.take_damage(dmg * (1 - d2 / turret["splash"] * 0.3), damage_type="physical")
                                if was_alive and not e2.alive:
                                    money_add_cb(e2.reward)
                                    self.kills += 1
                    else:
                        was_alive = target.alive
                        target.take_damage(dmg, damage_type="physical")
                        if was_alive and not target.alive:
                            money_add_cb(target.reward)
                            self.kills += 1
                    self.damage_done += dmg
                    turret["cooldown"] = 1.0 / self.turret_speed
        return None

    def _update_thunderer(self, dt, enemies, money_add_cb):
        """Громовержець - електрика що перескакує між ворогами з втратою урону.
        Може бити летунів тільки через ланцюгову реакцію."""
        stats = self.get_stats()

        # вибираємо ціль - тільки наземні для першої атаки
        if self.target is None or not self.target.alive or \
                math.hypot(self.target.x - self.x, self.target.y - self.y) > stats["range"] or \
                self.target.is_flying:  # не можемо напряму бити летунів
            self.target = self._pick_target(enemies, False)  # False = не бачить летунів

        if self.target is None or self.cooldown > 0:
            return None

        fr = max(0.05, stats["fire_rate"])
        self.cooldown = 1.0 / fr

        # Ланцюгова атака - перший ворог обов'язково наземний
        hit_enemies = []
        current = self.target
        dmg = stats["damage"] * self.damage_multiplier
        falloff = self.chain_falloff
        max_chain = self.chain_max

        while current and len(hit_enemies) < max_chain:
            hit_enemies.append(current)
            # шукаємо наступного найближчого ворога (тепер можна і летунів!)
            best_next = None
            best_dist = float('inf')
            for e in enemies:
                if not e.alive or e in hit_enemies:
                    continue
                # тепер може перескакувати на летунів!
                d = math.hypot(e.x - current.x, e.y - current.y)
                if d < 120 and d < best_dist:
                    best_dist = d
                    best_next = e
            current = best_next
            dmg *= (1.0 - falloff)  # втрата урону з кожним ворогом

        # завдаємо урон
        for i, e in enumerate(hit_enemies):
            actual_dmg = stats["damage"] * self.damage_multiplier * ((1.0 - falloff) ** i)
            was_alive = e.alive
            e.take_damage(actual_dmg, armor_pierce=stats["armor_pierce"], damage_type="physical")
            if was_alive and not e.alive:
                money_add_cb(e.reward)
                self.kills += 1
            self.damage_done += actual_dmg

        # візуалізація блискавки
        if hit_enemies:
            proj = Projectile(
                self.x, self.y, hit_enemies[0], stats["damage"], 0, (100, 200, 255),
                splash_radius=0, armor_pierce=stats["armor_pierce"],
            )
            proj.alive = False
            proj.is_chain = True
            proj.chain_targets = hit_enemies
            proj.chain_timer = 0.4
            return proj
        return None

    def buy_turret(self):
        """Інженер: купує турель."""
        if self.kind != "engineer" or len(self.turrets) >= self.turret_limit:
            return False
        angle = len(self.turrets) * (2 * math.pi / min(self.turret_limit, 8))
        r = 30
        tx = self.x + math.cos(angle) * r
        ty = self.y + math.sin(angle) * r
        self.turrets.append({
            "x": tx,
            "y": ty,
            "damage": self.turret_damage,
            "range": self.turret_range,
            "splash": self.turret_splash,
            "cooldown": 0,
            "can_hit_flying": False
        })
        self.total_spent += 50
        return True