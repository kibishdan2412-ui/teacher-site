# -*- coding: utf-8 -*-
"""Клас Level - одна ігрова сесія (рівень кампанії або безперервний режим)."""
import math
import random
import pygame

import settings as S
from ui import Button, draw_text, draw_bar, FONT_S, FONT_M, FONT_L, FONT_XL
from towers import Tower, TOWER_BASE, TOWER_TREES, ATTACK_TOWERS
from enemies import create_enemy, ENEMY_BASE
import waves as W

ROAD_HALF_WIDTH = 24
BLOCK_MARGIN = 34

SHOP_ORDER = ["basic", "sniper", "aura", "support", "pyro", "glue", "demoman", "engineer", "thunderer"]


def point_seg_dist(px, py, x1, y1, x2, y2):
    dx, dy = x2 - x1, y2 - y1
    if dx == dy == 0:
        return math.hypot(px - x1, py - y1)
    t = ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)
    t = max(0, min(1, t))
    cx, cy = x1 + t * dx, y1 + t * dy
    return math.hypot(px - cx, py - cy)


def dist_to_path(px, py, path):
    return min(point_seg_dist(px, py, x1, y1, x2, y2)
               for (x1, y1), (x2, y2) in zip(path, path[1:]))


class Level:
    def __init__(self, screen, level_def=None, endless=False, endless_start_wave=1):
        self.screen = screen
        self.endless = endless
        if endless:
            self.name = "Безперервний режим"
            self.path = W.ENDLESS_PATH
            self.money = S.START_MONEY_DEFAULT + 50
            self.lives = S.START_LIVES_DEFAULT
            self.total_waves = None
        else:
            self.level_def = level_def
            self.name = level_def["name"]
            self.path = level_def["path"]
            self.money = level_def["start_money"]
            self.lives = level_def["start_lives"]
            self.total_waves = len(level_def["waves"])

        self.grid_w = S.FIELD_WIDTH // S.GRID
        self.grid_h = S.SCREEN_HEIGHT // S.GRID
        self.blocked_cells = self._compute_blocked_cells()

        self.towers = []
        self.enemies = []
        self.projectiles = []
        self.floating_texts = []
        self.enemy_spawn_queue = []

        self.wave_number = 0
        self.wave_active = False
        self.spawn_queue = []
        self.spawn_timer = 0.0
        self.spawn_interval = 0.6
        self.enemy_scale = 1.0
        self.between_wave_timer = 3.0
        self.auto_start_timer = 8.0

        self.state = "playing"
        self.fast_forward = False
        self.selected_shop = None
        self.selected_tower = None
        self.hover_cell = None

        self.field_rect = pygame.Rect(0, 0, S.FIELD_WIDTH, S.SCREEN_HEIGHT)
        self.field_surf = screen.subsurface(self.field_rect)

        self._build_shop_buttons()
        self.next_wave_btn = Button((S.FIELD_WIDTH + 20, S.SCREEN_HEIGHT - 60, 260, 40),
                                     "Почати хвилю", font=FONT_M)
        self.ff_btn = Button((S.FIELD_WIDTH + 20, S.SCREEN_HEIGHT - 105, 260, 35),
                              "Прискорення: вимк", font=FONT_S)
        self.sell_btn = None
        self.upgrade_buttons = []
        self.buy_turret_btn = None

    # ------------------------------------------------------------------
    def _compute_blocked_cells(self):
        blocked = set()
        for gy in range(self.grid_h):
            for gx in range(self.grid_w):
                cx, cy = gx * S.GRID + S.GRID / 2, gy * S.GRID + S.GRID / 2
                if dist_to_path(cx, cy, self.path) < BLOCK_MARGIN:
                    blocked.add((gx, gy))
        return blocked

    def _build_shop_buttons(self):
        self.shop_buttons = {}
        y = 55
        for kind in SHOP_ORDER:
            rect = (S.FIELD_WIDTH + 15, y, 270, 46)
            base = TOWER_BASE[kind]
            self.shop_buttons[kind] = Button(rect, f"{base['name']}  ({base['cost']}$)", font=FONT_S)
            y += 52

    # ------------------------------------------------------------------
    def money_add(self, amount):
        self.money += amount

    def add_floating_text(self, x, y, text, color):
        self.floating_texts.append([x, y, text, color, 1.0])

    # ------------------------------------------------------------------
    def start_next_wave(self):
        if self.wave_active:
            return
        self.wave_number += 1
        if self.endless:
            wdef = W.generate_endless_wave(self.wave_number)
        else:
            if self.wave_number > len(self.level_def["waves"]):
                return
            wdef = self.level_def["waves"][self.wave_number - 1]
        self.spawn_queue = list(wdef["enemies"])
        self.spawn_interval = wdef["interval"]
        self.enemy_scale = wdef["scale"]
        self.spawn_timer = 0.0
        self.wave_active = True
        self.between_wave_timer = 999
        self.auto_start_timer = 999

    def _grid_to_pixel_center(self, gx, gy):
        return gx * S.GRID + S.GRID / 2, gy * S.GRID + S.GRID / 2

    def _cell_at(self, mx, my):
        if mx < 0 or my < 0 or mx >= S.FIELD_WIDTH or my >= S.SCREEN_HEIGHT:
            return None
        return int(mx // S.GRID), int(my // S.GRID)

    def _tower_at_cell(self, gx, gy):
        for t in self.towers:
            if t.grid_x == gx and t.grid_y == gy:
                return t
        return None

    # ------------------------------------------------------------------
    def handle_event(self, event):
        mouse_pos = pygame.mouse.get_pos()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.selected_shop = None
                self.selected_tower = None
            elif event.key == pygame.K_SPACE:
                self.fast_forward = not self.fast_forward

        if event.type != pygame.MOUSEBUTTONDOWN:
            return
        left_click = event.button == 1
        right_click = event.button == 3

        if right_click:
            self.selected_shop = None
            self.selected_tower = None
            return

        if not left_click:
            return

        if self.selected_tower is None:
            for kind, btn in self.shop_buttons.items():
                if btn.rect.collidepoint(mouse_pos):
                    cost = TOWER_BASE[kind]["cost"]
                    if self.money >= cost:
                        self.selected_shop = kind
                        self.selected_tower = None
                    return

        if self.next_wave_btn.rect.collidepoint(mouse_pos) and not self.wave_active:
            if self.endless or self.wave_number < len(self.level_def["waves"]):
                self.start_next_wave()
            return

        if self.ff_btn.rect.collidepoint(mouse_pos):
            self.fast_forward = not self.fast_forward
            return

        if self.buy_turret_btn and self.buy_turret_btn.rect.collidepoint(mouse_pos):
            if self.selected_tower and self.selected_tower.kind == "engineer":
                if self.money >= 50 and len(self.selected_tower.turrets) < self.selected_tower.turret_limit:
                    if self.selected_tower.buy_turret():
                        self.money -= 50
                        self.add_floating_text(self.selected_tower.x, self.selected_tower.y - 30,
                                             f"+1 турель", S.COLOR_GOOD)
                return

        if self.selected_tower is not None:
            for i, btn in enumerate(self.upgrade_buttons):
                if btn.rect.collidepoint(mouse_pos) and btn.enabled:
                    opt = self.selected_tower.upgrade_options()[i]
                    if self.money >= opt["cost"]:
                        self.money -= opt["cost"]
                        self.selected_tower.apply_upgrade(opt["branch"], opt["tier"])
                        self.add_floating_text(self.selected_tower.x, self.selected_tower.y - 30,
                                             f"Апгрейд!", S.COLOR_GOLD)
                    return
            if self.sell_btn and self.sell_btn.rect.collidepoint(mouse_pos):
                refund = self.selected_tower.sell_value()
                self.money += refund
                self.towers.remove(self.selected_tower)
                self.selected_tower = None
                return

        if mouse_pos[0] < S.FIELD_WIDTH:
            cell = self._cell_at(*mouse_pos)
            if cell is None:
                return
            gx, gy = cell
            existing = self._tower_at_cell(gx, gy)

            if self.selected_shop is not None:
                if existing is None and cell not in self.blocked_cells:
                    cost = TOWER_BASE[self.selected_shop]["cost"]
                    if self.money >= cost:
                        px, py = self._grid_to_pixel_center(gx, gy)
                        t = Tower(self.selected_shop, px, py, gx, gy)
                        if self.selected_shop == "demoman":
                            t.mine_damage = 50
                            t.mine_limit = 10
                            t.mine_range = t.base["range"]
                            t.mine_splash = 20
                            t.path = self.path  # передаємо шлях для демомена
                        elif self.selected_shop == "engineer":
                            t.turret_damage = 15
                            t.turret_speed = 0.8
                            t.turret_range = 180
                            t.turret_splash = 0
                        elif self.selected_shop == "thunderer":
                            t.chain_falloff = 0.15
                        self.towers.append(t)
                        self.money -= cost
                        self.selected_shop = None
                        self.selected_tower = t
                return

            if existing is not None:
                self.selected_tower = existing
                self.selected_shop = None
            else:
                self.selected_tower = None

    # ------------------------------------------------------------------
    def update(self, dt_real):
        if self.state != "playing":
            return
        dt = dt_real * (S.FAST_FORWARD_MULT if self.fast_forward else 1.0)

        if self.wave_active:
            self.spawn_timer -= dt
            if self.spawn_timer <= 0 and self.spawn_queue:
                kind = self.spawn_queue.pop(0)
                enemy = create_enemy(kind, self.path, self.enemy_scale)
                self.enemies.append(enemy)
                self.spawn_timer = self.spawn_interval
            if not self.spawn_queue and not any(e.alive for e in self.enemies):
                self.wave_active = False
                if not self.endless and self.wave_number >= len(self.level_def["waves"]):
                    self.state = "won"
                    return
                self.between_wave_timer = 6.0

        if not self.wave_active and self.state == "playing":
            if self.between_wave_timer < 900:
                self.between_wave_timer -= dt
                if self.between_wave_timer <= 0:
                    self.start_next_wave()

        # скидання бафів
        for t in self.towers:
            t.buff_damage = 0.0
            t.buff_speed = 0.0
            t.buff_pierce = 0.0
            t.buff_boss = 0.0
            t.buff_special = 0.0
            t.buff_range = 0.0

        # застосування бафів роздатчика
        for t in self.towers:
            if t.kind != "support":
                continue
            stats = t.get_stats()
            for other in self.towers:
                if other is t or other.kind == "support":
                    continue
                d = math.hypot(other.x - t.x, other.y - t.y)
                if d <= stats["range"]:
                    m = t._accumulated_mods()
                    other.buff_damage += m.get("buff_damage", 0)
                    other.buff_speed += m.get("buff_speed", 0)
                    other.buff_pierce = max(other.buff_pierce, m.get("buff_pierce", 0))
                    other.buff_boss += m.get("buff_boss", 0)
                    other.buff_special += m.get("buff_special", 0)
                    other.buff_range += m.get("buff_range", 0)

                    if other.kind == "demoman":
                        other.mine_damage *= (1.0 + other.buff_special)
                    elif other.kind == "engineer":
                        other.turret_damage *= (1.0 + other.buff_special)
                        other.turret_speed *= (1.0 + other.buff_special)
                    elif other.kind == "thunderer":
                        other.damage_multiplier = 1.0 + other.buff_special

        # оновлення веж
        for t in self.towers:
            proj = t.update(dt, self.enemies, self._on_kill_money)
            if proj is not None:
                self.projectiles.append(proj)

        # снаряди
        alive_proj = []
        for p in self.projectiles:
            still = p.update(dt, self.enemies, self._on_kill_money)
            if still:
                alive_proj.append(p)
        self.projectiles = alive_proj

        # вороги
        for e in self.enemies:
            was_alive = e.alive
            e.update(dt)
            if was_alive and e.reached_end:
                self.lives -= 1
                self.add_floating_text(e.x, e.y, "-1", S.COLOR_BAD)

        # обробка роздільників - ПІСЛЯ того, як вежі/снаряди могли вбити їх у цьому кадрі,
        # і ДО фільтрації мертвих (інакше мертвий спліттер вже зникне зі списку і split()
        # ніколи не викличеться)
        new_enemies = []
        for e in self.enemies:
            if not e.alive and e.kind == "splitter" and not e.is_split:
                children = e.split(self.path)
                new_enemies.extend(children)
        self.enemies.extend(new_enemies)

        self.enemies = [e for e in self.enemies if e.alive]

        for ft in self.floating_texts:
            ft[4] -= dt_real
            ft[1] -= 20 * dt_real
        self.floating_texts = [ft for ft in self.floating_texts if ft[4] > 0]

        if self.lives <= 0:
            self.lives = 0
            self.state = "lost"

        if self.selected_tower is not None and self.selected_tower not in self.towers:
            self.selected_tower = None

    def _on_kill_money(self, amount):
        self.money += amount

    # ------------------------------------------------------------------
    def _draw_field_bg(self):
        surf = self.field_surf
        for gy in range(self.grid_h):
            for gx in range(self.grid_w):
                color = S.COLOR_GRASS_1 if (gx + gy) % 2 == 0 else S.COLOR_GRASS_2
                pygame.draw.rect(surf, color, (gx * S.GRID, gy * S.GRID, S.GRID, S.GRID))

        for (x1, y1), (x2, y2) in zip(self.path, self.path[1:]):
            pygame.draw.line(surf, S.COLOR_ROAD_EDGE, (x1, y1), (x2, y2), ROAD_HALF_WIDTH * 2 + 6)
        for (x1, y1), (x2, y2) in zip(self.path, self.path[1:]):
            pygame.draw.line(surf, S.COLOR_ROAD, (x1, y1), (x2, y2), ROAD_HALF_WIDTH * 2)

    def _draw_towers(self):
        surf = self.field_surf
        for t in self.towers:
            stats = t.get_stats()
            if t is self.selected_tower:
                s = pygame.Surface((S.FIELD_WIDTH, S.SCREEN_HEIGHT), pygame.SRCALPHA)
                pygame.draw.circle(s, (255, 255, 255, 40), (int(t.x), int(t.y)), int(stats["range"]))
                pygame.draw.circle(s, (255, 255, 255, 120), (int(t.x), int(t.y)), int(stats["range"]), width=2)
                surf.blit(s, (0, 0))

            base_r = 16

            if t.kind == "pyro":
                if t.laser_target and t.laser_target.alive:
                    pygame.draw.line(surf, (255, 100, 20),
                                   (int(t.x), int(t.y)),
                                   (int(t.laser_target.x), int(t.laser_target.y)), 3)
                    pygame.draw.line(surf, (255, 200, 50),
                                   (int(t.x), int(t.y)),
                                   (int(t.laser_target.x), int(t.laser_target.y)), 1)

            elif t.kind == "demoman":
                for mine in t.mines:
                    pygame.draw.circle(surf, (200, 50, 20), (int(mine["x"]), int(mine["y"])), 8)
                    pygame.draw.circle(surf, (255, 100, 50), (int(mine["x"]), int(mine["y"])), 5)

            elif t.kind == "engineer":
                for turret in t.turrets:
                    pygame.draw.circle(surf, (200, 200, 100), (int(turret["x"]), int(turret["y"])), 10)
                    pygame.draw.circle(surf, (255, 255, 150), (int(turret["x"]), int(turret["y"])), 6)
                    if turret["cooldown"] > 0:
                        ratio = 1 - turret["cooldown"] / (1.0 / t.turret_speed)
                        pygame.draw.arc(surf, S.COLOR_GOOD,
                                      (turret["x"] - 14, turret["y"] - 14, 28, 28),
                                      -math.pi/2, -math.pi/2 + ratio * 2*math.pi, 2)

            flash = getattr(t, "pulse_flash", 0)
            if t.kind == "aura" and flash > 0:
                s = pygame.Surface((S.FIELD_WIDTH, S.SCREEN_HEIGHT), pygame.SRCALPHA)
                alpha = int(140 * (flash / 0.15))
                pygame.draw.circle(s, (*stats["color"], alpha), (int(t.x), int(t.y)), int(stats["range"]))
                surf.blit(s, (0, 0))

            pygame.draw.rect(surf, (25, 25, 30), (t.x - 20, t.y - 20, 40, 40), border_radius=8)
            pygame.draw.circle(surf, stats["color"], (int(t.x), int(t.y)), base_r)
            pygame.draw.circle(surf, (20, 20, 20), (int(t.x), int(t.y)), base_r, width=2)
            if t.branch:
                draw_text(surf, t.branch, (t.x, t.y), FONT_S, (20, 20, 20), center=True)

            if t.kind == "support":
                s = pygame.Surface((S.FIELD_WIDTH, S.SCREEN_HEIGHT), pygame.SRCALPHA)
                pygame.draw.circle(s, (*stats["color"], 25), (int(t.x), int(t.y)), int(stats["range"]))
                surf.blit(s, (0, 0))

        if self.selected_shop is not None and self.hover_cell is not None:
            gx, gy = self.hover_cell
            px, py = self._grid_to_pixel_center(gx, gy)
            valid = (gx, gy) not in self.blocked_cells and self._tower_at_cell(gx, gy) is None
            base = TOWER_BASE[self.selected_shop]
            s = pygame.Surface((S.FIELD_WIDTH, S.SCREEN_HEIGHT), pygame.SRCALPHA)
            color = (110, 220, 120, 90) if valid else (230, 90, 90, 110)
            pygame.draw.circle(s, color, (int(px), int(py)), base["range"])
            surf.blit(s, (0, 0))
            pygame.draw.circle(surf, (*base["color"], ), (int(px), int(py)), 16, width=3)

    def _draw_enemies(self):
        surf = self.field_surf
        for e in self.enemies:
            color = (255, 255, 255) if e.hit_flash > 0 else e.color
            if e.kind == "armored":
                color = (200, 200, 200) if e.hit_flash <= 0 else (255, 255, 255)
                pygame.draw.circle(surf, color, (int(e.x), int(e.y)), e.radius + 4)
                pygame.draw.circle(surf, (100, 100, 100), (int(e.x), int(e.y)), e.radius + 2)
            elif e.kind == "splitter":
                color = (220, 140, 140) if e.hit_flash <= 0 else (255, 255, 255)
                if e.is_split:
                    pygame.draw.circle(surf, color, (int(e.x), int(e.y)), e.radius)
                else:
                    pygame.draw.circle(surf, color, (int(e.x), int(e.y)), e.radius)
                    pygame.draw.circle(surf, (255, 100, 100), (int(e.x), int(e.y)), e.radius + 3, width=1)
            else:
                pygame.draw.circle(surf, color, (int(e.x), int(e.y)), e.radius)

            pygame.draw.circle(surf, (20, 20, 20), (int(e.x), int(e.y)), e.radius, width=1)
            if e.is_flying:
                pygame.draw.circle(surf, (255, 255, 255), (int(e.x), int(e.y)), e.radius + 3, width=1)
            if e.slow_timer > 0:
                pygame.draw.circle(surf, (120, 200, 255), (int(e.x), int(e.y)), e.radius + 5, width=1)
            if e.burn_timer > 0:
                pygame.draw.circle(surf, (255, 140, 40), (int(e.x), int(e.y)), e.radius + 7, width=1)

            bar_w = e.radius * 2
            draw_bar(surf, e.x - e.radius, e.y - e.radius - 9, bar_w, 4,
                     e.hp / e.max_hp, S.COLOR_GOOD if e.hp / e.max_hp > 0.4 else S.COLOR_BAD)

    def _draw_projectiles(self):
        for p in self.projectiles:
            p.draw(self.field_surf)

    def _draw_floating_texts(self):
        for x, y, text, color, timer in self.floating_texts:
            draw_text(self.field_surf, text, (x, y), FONT_S, color, center=True, shadow=True)

    # ------------------------------------------------------------------
    def _draw_sidebar(self):
        surf = self.screen
        rect = pygame.Rect(S.FIELD_WIDTH, 0, S.SIDEBAR_WIDTH, S.SCREEN_HEIGHT)
        pygame.draw.rect(surf, S.COLOR_SIDEBAR, rect)
        pygame.draw.line(surf, S.COLOR_SIDEBAR_LINE, (S.FIELD_WIDTH, 0), (S.FIELD_WIDTH, S.SCREEN_HEIGHT), 2)

        draw_text(surf, f"${int(self.money)}", (S.FIELD_WIDTH + 20, 12), FONT_L, S.COLOR_GOLD)
        lives_col = S.COLOR_GOOD if self.lives > 6 else S.COLOR_BAD
        draw_text(surf, f"♥ {self.lives}", (S.FIELD_WIDTH + 150, 16), FONT_M, lives_col)
        wtxt = f"Хвиля {self.wave_number}" + ("" if self.endless else f"/{self.total_waves}")
        draw_text(surf, wtxt, (S.FIELD_WIDTH + 220, 16), FONT_S, S.COLOR_TEXT_DIM)

        if self.selected_tower is None:
            for kind, btn in self.shop_buttons.items():
                btn.enabled = self.money >= TOWER_BASE[kind]["cost"]
                if self.selected_shop == kind:
                    btn.bg = (70, 90, 60)
                else:
                    btn.bg = S.COLOR_PANEL
                btn.draw(surf)
                base = TOWER_BASE[kind]
                draw_text(surf, base["desc"], (btn.rect.x + 8, btn.rect.y + 26), FONT_S, S.COLOR_TEXT_DIM)
        else:
            self._draw_upgrade_panel()

        self.next_wave_btn.enabled = not self.wave_active and (
            self.endless or self.wave_number < len(self.level_def["waves"]))
        if self.wave_active:
            self.next_wave_btn.text = "Хвиля триває..."
        elif not self.endless and self.wave_number >= len(self.level_def["waves"]) and self.wave_number > 0:
            self.next_wave_btn.text = "Всі хвилі пройдено"
            self.next_wave_btn.enabled = False
        else:
            secs = max(0, int(self.between_wave_timer)) if self.between_wave_timer < 900 else None
            self.next_wave_btn.text = f"Почати хвилю ({secs}с)" if secs else "Почати хвилю"
        self.next_wave_btn.update(pygame.mouse.get_pos())
        self.next_wave_btn.draw(surf)

        self.ff_btn.text = f"Прискорення x{S.FAST_FORWARD_MULT:.1f}: {'ВКЛ' if self.fast_forward else 'вимк'}"
        self.ff_btn.update(pygame.mouse.get_pos())
        self.ff_btn.draw(surf)

        draw_text(surf, self.name, (S.FIELD_WIDTH + 20, S.SCREEN_HEIGHT - 130), FONT_S, S.COLOR_TEXT_DIM)
        draw_text(surf, "ПКМ/Esc — скасування. Пробіл — прискорення.",
                  (S.FIELD_WIDTH + 20, S.SCREEN_HEIGHT - 148), FONT_S, S.COLOR_TEXT_DIM)

    def _draw_upgrade_panel(self):
        surf = self.screen
        t = self.selected_tower
        base = TOWER_BASE[t.kind]
        x = S.FIELD_WIDTH + 15
        y = 55

        panel_h = 180
        pygame.draw.rect(surf, S.COLOR_PANEL, (x, y, 270, panel_h), border_radius=8)
        draw_text(surf, base["name"], (x + 10, y + 8), FONT_M, S.COLOR_TEXT)

        if t.kind == "demoman":
            info = f"Мін: {len(t.mines)}/{t.mine_limit} | Урон: {t.mine_damage} | Сплеш: {t.mine_splash}"
            draw_text(surf, info, (x + 10, y + 30), FONT_S, S.COLOR_TEXT_DIM)
        elif t.kind == "engineer":
            info = f"Турелей: {len(t.turrets)}/{t.turret_limit} | Урон: {t.turret_damage:.0f}"
            draw_text(surf, info, (x + 10, y + 30), FONT_S, S.COLOR_TEXT_DIM)
            info2 = f"Швидк.: {t.turret_speed:.1f}/с | Дальн.: {t.turret_range:.0f}"
            draw_text(surf, info2, (x + 10, y + 48), FONT_S, S.COLOR_TEXT_DIM)
            can_buy = len(t.turrets) < t.turret_limit and self.money >= 50
            btn_rect = (x + 10, y + 66, 250, 28)
            self.buy_turret_btn = Button(btn_rect, f"Купити турель (50$)",
                                        font=FONT_S, enabled=can_buy)
            self.buy_turret_btn.update(pygame.mouse.get_pos())
            self.buy_turret_btn.draw(surf)
            panel_h = 220
        elif t.kind == "thunderer":
            stats = t.get_stats()
            info = f"Урон: {stats['damage']:.0f} | Втрата: {t.chain_falloff*100:.0f}% | Дальн.: {stats['range']:.0f}"
            draw_text(surf, info, (x + 10, y + 30), FONT_S, S.COLOR_TEXT_DIM)
            panel_h = 200
        else:
            branch_txt = f"Гілка: {t.branch or '—'}  Рівень: {t.tier}/3"
            draw_text(surf, branch_txt, (x + 10, y + 30), FONT_S, S.COLOR_TEXT_DIM)
            stats = t.get_stats()
            info_lines = [f"Урон: {stats['damage']:.0f}   Дальн.: {stats['range']:.0f}"]
            if t.kind != "support" and t.kind not in ["demoman", "engineer", "thunderer"]:
                info_lines.append(f"Швидк.: {stats['fire_rate']:.2f}/с")
            if stats.get("armor_pierce"):
                info_lines.append(f"Ігнор броні: {int(stats['armor_pierce']*100)}%")
            draw_text(surf, "  |  ".join(info_lines[:1]), (x + 10, y + 56), FONT_S, S.COLOR_TEXT_DIM)
            if len(info_lines) > 1:
                draw_text(surf, "  |  ".join(info_lines[1:]), (x + 10, y + 74), FONT_S, S.COLOR_TEXT_DIM)

        y_offset = panel_h - 40
        draw_text(surf, f"Вбивств: {t.kills}   Урону: {int(t.damage_done)}",
                  (x + 10, y + y_offset - 10), FONT_S, S.COLOR_TEXT_DIM)

        sell_rect = (x, y + panel_h - 4, 270, 30)
        self.sell_btn = Button(sell_rect, f"Продати (+{t.sell_value()}$)", font=FONT_S,
                                bg=(70, 35, 35), bg_hover=(95, 45, 45))
        self.sell_btn.update(pygame.mouse.get_pos())
        self.sell_btn.draw(surf)

        if t.kind != "engineer":
            y2 = y + panel_h + 40
            draw_text(surf, "Прокачування:", (x + 10, y2), FONT_M, S.COLOR_TEXT)
            y2 += 26
            self.upgrade_buttons = []
            options = t.upgrade_options()
            if not options:
                draw_text(surf, "Максимальний рівень досягнуто!", (x + 10, y2), FONT_S, S.COLOR_GOOD)
            for opt in options:
                can_afford = self.money >= opt["cost"]
                rect = (x, y2, 270, 64)
                btn = Button(rect, "", font=FONT_S, enabled=can_afford)
                btn.update(pygame.mouse.get_pos())
                btn.draw(surf)
                title = f"[{opt['branch']}] {opt['title']}  ({opt['cost']}$)"
                color = S.COLOR_TEXT if can_afford else S.COLOR_TEXT_DIM
                draw_text(surf, title, (rect[0] + 8, rect[1] + 6), FONT_S, color)
                draw_text(surf, opt["branch_name"], (rect[0] + 8, rect[1] + 24), FONT_S, S.COLOR_WARN)
                desc = opt["desc"]
                draw_text(surf, desc, (rect[0] + 8, rect[1] + 42), FONT_S, S.COLOR_TEXT_DIM)
                self.upgrade_buttons.append(btn)
                y2 += 70

    # ------------------------------------------------------------------
    def draw(self):
        self.screen.fill(S.COLOR_BG)
        mx, my = pygame.mouse.get_pos()
        self.hover_cell = self._cell_at(mx, my) if mx < S.FIELD_WIDTH else None

        self._draw_field_bg()
        self._draw_towers()
        self._draw_enemies()
        self._draw_projectiles()
        self._draw_floating_texts()
        self._draw_sidebar()

        if self.state == "lost":
            self._draw_overlay("ПОРАЗКА", S.COLOR_BAD, f"Хвиля: {self.wave_number}")
        elif self.state == "won":
            self._draw_overlay("ПЕРЕМОГА!", S.COLOR_GOOD, "Рівень пройдено")

    def _draw_overlay(self, title, color, subtitle):
        s = pygame.Surface((S.FIELD_WIDTH, S.SCREEN_HEIGHT), pygame.SRCALPHA)
        s.fill((0, 0, 0, 170))
        self.screen.blit(s, (0, 0))
        draw_text(self.screen, title, (S.FIELD_WIDTH // 2, S.SCREEN_HEIGHT // 2 - 40),
                  FONT_XL, color, center=True, shadow=True)
        draw_text(self.screen, subtitle, (S.FIELD_WIDTH // 2, S.SCREEN_HEIGHT // 2 + 10),
                  FONT_M, S.COLOR_TEXT, center=True)
        draw_text(self.screen, "Натисніть ENTER, щоб повернутися в меню",
                  (S.FIELD_WIDTH // 2, S.SCREEN_HEIGHT // 2 + 45), FONT_S, S.COLOR_TEXT_DIM, center=True)